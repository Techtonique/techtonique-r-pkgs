# healthsimulation

Generate Synthetic Healthcare data for research

[![Documentation](https://img.shields.io/badge/documentation-is_here-green)](https://techtonique.github.io/healthsimulation/index.html)


### Installation

- __1st method__, released version: from [Techtonique's R package's repository](https://r-packages.techtonique.net)

    In R console:
    
    ```R
    options(repos = c(
                    techtonique = "https://r-packages.techtonique.net",
                    CRAN = "https://cloud.r-project.org"
                ))            
        
    install.packages("healthsimulation")
    ```

- __2nd method__: from Github

    In R console:
    
    ```R
    devtools::install_github("Techtonique/healthsimulation")
    ```

### Demo

```R
library(healthsimulation)

sim <- SmartHealthSimulator$new(days = 180, seed = 42)
head(sim$data)
sim$plot_time_series()
sim$plot_mood_sleep()
sim$plot_activity_distribution()
sim$plot_mood_wordcloud()
```

