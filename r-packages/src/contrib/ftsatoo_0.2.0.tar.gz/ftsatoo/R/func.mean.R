func.mean <- function(functions)
{
   apply(functions, 2, mean)
}

