sd <- function(...) 
UseMethod("sd")
