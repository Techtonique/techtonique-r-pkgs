func.med.RPD <- function(functions, deriv = c(0, 1))
{
  depth.RPD(functions, deriv = deriv)$median
}
