# Cpp functions (used in summary and sensi1 and 2D)
#derivs <- memoise::memoize(derivs)
#inters <- memoise::memoize(inters)
#inters2 <- memoise::memoize(inters2)
  
#' Compute the first and second order derivatives of the response function
#'
#' @param fit_obj Fitted object
#'
#' @return
#' @export
#'
#' @examples
derivatives <- function(fit_obj, obs = NULL)
{
  # DRY this: scaled_x
  
  if (!fit_obj$with_kmeans)
  {
    n <- nrow(fit_obj$scaled_x)
    
    if(n > 500)
      cat("Processing...", "\n")
    
    if (!is.null(dim(fit_obj$coef)))
    {
      i_best <- switch(fit_obj$fit_method, 
                       "svd" = which.min(fit_obj$GCV),
                       "eigen" = which.min(fit_obj$loocv),
                       "chol" = which.min(fit_obj$loocv), 
                       "solve" = which.min(fit_obj$loocv))
      
      res <- derivs(x = fit_obj$scaled_x, 
                    c = fit_obj$coef[, i_best], 
                    l = fit_obj$l[1])
    } else {
      res <- derivs(x = fit_obj$scaled_x, 
                    c = fit_obj$coef, 
                    l = fit_obj$l[1])
    }
    
    if (is.null(obs)) # all the observations
    {
      col_names_x <- colnames(fit_obj$scaled_x)
      
      if (!is.null(col_names_x))  
        colnames(res[[1]]) <- colnames(res[[2]]) <- col_names_x
      
      rownames(res[[1]]) <- rownames(res[[2]]) <- paste(rep(1:n, each = n),
                                                        rep(1:n), sep = ".")
      
      names(res) <- c("1D", "2D")
      
      return(res)
      
    } else { # one observation
      
      stopifnot(obs >= 1 && obs <= n && floor(obs) == obs)
      upper_bound <- n*obs
      lower_bound <- n*obs - n + 1
      res <- list(res[[1]][lower_bound:upper_bound, ], 
                  res[[2]][lower_bound:upper_bound, ])
      
      col_names_x <- colnames(fit_obj$scaled_x)
      
      if (!is.null(col_names_x))  
        colnames(res[[1]]) <- colnames(res[[2]]) <- col_names_x
      
      rownames(res[[1]]) <- rownames(res[[2]]) <- seq(1, n, by = 1)
      
      names(res) <- c("1D", "2D")
      
      return(res)
    }
  } else { # fit_obj$with_kmeans == TRUE
    
    n <- nrow(fit_obj$scaled_x_clust)
    
    if(n > 500)
      cat("Processing...", "\n")
    
    if (!is.null(dim(fit_obj$coef)))
    {
      i_best <- switch(fit_obj$fit_method, 
                       "svd" = which.min(fit_obj$GCV),
                       "eigen" = which.min(fit_obj$loocv),
                       "chol" = which.min(fit_obj$loocv), 
                       "solve" = which.min(fit_obj$loocv))
      
      res <- derivs(x = fit_obj$scaled_x_clust, 
                    c = fit_obj$coef[, i_best], 
                    l = fit_obj$l[1])
    } else {
      res <- derivs(x = fit_obj$scaled_x_clust, 
                    c = fit_obj$coef, 
                    l = fit_obj$l[1])
    }
    
    if (is.null(obs)) # all the observations
    {
      col_names_x <- colnames(fit_obj$scaled_x_clust)
      
      if (!is.null(col_names_x))  
        colnames(res[[1]]) <- colnames(res[[2]]) <- col_names_x
      
      rownames(res[[1]]) <- rownames(res[[2]]) <- paste(rep(1:n, each = n),
                                                        rep(1:n), sep = ".")
      
      names(res) <- c("1D", "2D")
      
      return(res)
      
    } else { # one observation
      
      stopifnot(obs >= 1 && obs <= n && floor(obs) == obs)
      upper_bound <- n*obs
      lower_bound <- n*obs - n + 1
      res <- list(res[[1]][lower_bound:upper_bound, ], 
                  res[[2]][lower_bound:upper_bound, ])
      
      col_names_x <- colnames(fit_obj$scaled_x_clust)
      
      if (!is.null(col_names_x))  
        colnames(res[[1]]) <- colnames(res[[2]]) <- col_names_x
      
      rownames(res[[1]]) <- rownames(res[[2]]) <- seq(1, n, by = 1)
      
      names(res) <- c("1D", "2D")
      
      return(res)
    }
    
  }
}
#derivatives <- memoise::memoize(derivatives)


#' Title
#'
#' @param fit_obj 
#' @param index_col1 
#' @param index_col2 
#' @param obs 
#'
#' @return
#' @export
#'
#' @examples
interactions <- function(fit_obj, index_col1 = 1, index_col2 = 2, obs = NULL)
{
  
  if (!fit_obj$with_kmeans)
  {
    n <- nrow(fit_obj$scaled_x)
    p <- ncol(fit_obj$scaled_x)
    l <- sqrt(p)
    
    if (!is.null(dim(fit_obj$coef)))
    {
      i_best <- switch(fit_obj$fit_method, 
                       "svd" = which.min(fit_obj$GCV),
                       "eigen" = which.min(fit_obj$loocv),
                       "chol" = which.min(fit_obj$loocv), 
                       "solve" = which.min(fit_obj$loocv))
      
      res_inters <- inters(x = as.matrix(fit_obj$scaled_x), j1 = index_col1,
                           j2 = index_col2, c = fit_obj$coef[ , i_best], 
                           l = l)
    } else {
      res_inters <- inters(x = as.matrix(fit_obj$scaled_x), j1 = index_col1,
                           j2 = index_col2, c = fit_obj$coef, 
                           l = l)
    }
    colnames(res_inters) <- paste(rep(1, n),
                                  seq(1, n), sep = ".")
    rownames(res_inters) <- paste(seq(1, n),
                                  rep(1, n), sep = ".")
    
    if (is.null(obs)) # for all the observations 
    {
      if (!is.null(colnames(fit_obj$scaled_x)))
      {
        col_names <- colnames(fit_obj$scaled_x)
        cat("Interaction effects between", col_names[index_col1],
            " and ", col_names[index_col2], ":\n") 
      }
      
      print(summary(as.vector(res_inters)))
      return(invisible(res_inters)) 
    } else { # for one observation
      
      stopifnot(obs >= 1 && obs <= n && floor(obs) == obs)
      if (!is.null(colnames(fit_obj$scaled_x)))
      {
        col_names <- colnames(fit_obj$scaled_x)
        cat("Interaction effects between", col_names[index_col1],
            " and ", col_names[index_col2], "for observation #", obs, ":\n") 
      }
      
      print(summary(as.vector(res_inters[obs, ])))
      return(invisible(res_inters[obs, ])) 
    }
  } else { # is.null(with_kmeans) == FALSE
    
    n <- nrow(fit_obj$scaled_x_clust)
    p <- ncol(fit_obj$scaled_x_clust)
    l <- sqrt(p)
    
    if (!is.null(dim(fit_obj$coef)))
    {
      i_best <- switch(fit_obj$fit_method, 
                       "svd" = which.min(fit_obj$GCV),
                       "eigen" = which.min(fit_obj$loocv),
                       "chol" = which.min(fit_obj$loocv), 
                       "solve" = which.min(fit_obj$loocv))
      
      res_inters <- inters(x = as.matrix(fit_obj$scaled_x_clust), j1 = index_col1,
                           j2 = index_col2, c = fit_obj$coef[ , i_best], 
                           l = l)
    } else {
      res_inters <- inters(x = as.matrix(fit_obj$scaled_x_clust), j1 = index_col1,
                           j2 = index_col2, c = fit_obj$coef, 
                           l = l)
    }
    colnames(res_inters) <- paste(rep(1, n),
                                  seq(1, n), sep = ".")
    rownames(res_inters) <- paste(seq(1, n),
                                  rep(1, n), sep = ".")
    
    if (is.null(obs)) # for all the observations 
    {
      if (!is.null(colnames(fit_obj$scaled_x_clust)))
      {
        col_names <- colnames(fit_obj$scaled_x_clust)
        cat("Interaction effects between", col_names[index_col1],
            " and ", col_names[index_col2], ":\n") 
      }
      
      print(summary(as.vector(res_inters)))
      return(invisible(res_inters)) 
    } else { # for one observation
      
      stopifnot(obs >= 1 && obs <= n && floor(obs) == obs)
      if (!is.null(colnames(fit_obj$scaled_x_clust)))
      {
        col_names <- colnames(fit_obj$scaled_x_clust)
        cat("Interaction effects between", col_names[index_col1],
            " and ", col_names[index_col2], "for observation #", obs, ":\n") 
      }
      
      print(summary(as.vector(res_inters[obs, ])))
      return(invisible(res_inters[obs, ])) 
    }
    
  }

}
#interactions <- memoise::memoize(interactions)