# bayesianrvfl

[![Documentation](https://img.shields.io/badge/documentation-is_here-green)](https://techtonique.github.io/bayesianrvfl/index.html)
![Downloads](https://r-packages.techtonique.net/badges/downloads/last-month/bayesianrvfl.svg)
![Total Downloads](https://r-packages.techtonique.net/badges/downloads/grand-total/bayesianrvfl.svg?color=brightgreen)


Adaptive Bayesian (NON)Linear regression. 

See:

- [Online Bayesian Quasi-Random functional link networks; application to the optimization of black box functions](https://www.researchgate.net/publication/332292006_Online_Bayesian_Quasi-Random_functional_link_networks_application_to_the_optimization_of_black_box_functions)

- [https://thierrymoudiki.github.io/blog/2024/08/12/r/bqrvfl](https://thierrymoudiki.github.io/blog/2024/08/12/r/bqrvfl)

## Install 

```R
options(repos = c(
                    techtonique = "https://r-packages.techtonique.net",
                    CRAN = "https://cloud.r-project.org"
                ))

install.packages("bayesianrvfl")                
```

## Note to self

```bash
git push https://{TOKEN}@github.com/thierrymoudiki/bayesianrvfl.git
```
