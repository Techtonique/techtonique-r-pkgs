# matern32 

Kernel Ridge Regression using Matern 3/2 kernel. 

Read the vignettes (articles). 