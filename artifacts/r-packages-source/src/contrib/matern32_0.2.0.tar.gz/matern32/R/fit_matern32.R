#' Fit Matern 3/2 model
#'
#' @param x Matrix of predictors
#' @param y Vector of response values
#' @param sigma Hyperparameter for the Matern 3/2 kernel
#' @param l Hyperparameter for the Matern 3/2 kernel
#' @param lambda Regularization parameter
#' @param method Method to use for fitting the model
#' @param with_kmeans Use k-means to reduce the number of observations
#' @param centers Number of centers to use in k-means
#' @param centering Center the response
#' @param seed Seed for reproducibility
#' @param ... Additional arguments
#' 
#' @param ... 
#'
#' @return
#' @export
#'
#' @examples
#' 
#' n <- 100; p <- 4
#' 
#' set.seed(456)
#' X <- matrix(rnorm(n * p), n, p) # no intercept!
#' y <- rnorm(n)
#' 
#' lams <- 10^seq(-5, 4, length.out = 50)
#' 
#' fit_obj <- matern32::fit_matern32(x = X, y = y, lambda = lams)
#'
#' par(mfrow=c(1, 2))
#'  
#' plot(log(lams), fit_obj$GCV, type = 'l', main = "GCV", 
#' ylab = "GCV")
#' 
#' matplot(log(lams), t(fit_obj$coef), type = 'l', 
#' main = "coefficients = f(lambda)", xlab = "log(lambda)", 
#' ylab = "coefs")
#' abline(h = 0, lty = 2, lwd = 2, col = "red")
#' 
#'matern32::summary.matern32(fit_obj)
#' 
#' 
#' library(MASS)
#' X <-  longley[,-7]
#' y <- longley[, 7]
#' fit_obj <- matern32::fit_matern32(x = X, y = y)
#' 
#' par(mfrow=c(1, 2))
#'  
#' plot(log(fit_obj$lambda), fit_obj$GCV, type = 'l', main = "GCV", 
#' ylab = "GCV")
#' 
#' matplot(log(fit_obj$lambda), t(fit_obj$coef), type = 'l', 
#' main = "coefficients = f(lambda)", xlab = "log(lambda)", 
#' ylab = "coefs")
#' abline(h = 0, lty = 2, lwd = 2, col = "red")
#' 
#'matern32::summary.matern32(fit_obj)
#' 
#' library(MASS)
#'
#'X <- as.matrix(Boston[,-14])
#'y <- Boston[,14]
#'
#'fit_obj <- matern32::fit_matern32(x = X, y = y, lambda = lams)
#'
#'matern32::summary.matern32(fit_obj)
#'  
fit_matern32 <- function(x, y, lambda = 10^seq(-10, 10, length.out = 100),#10^seq(-5, 4, length.out = 100),
                         l = NULL, method = c("chol", "solve", "svd", "eigen", "conformal"),
                         with_kmeans = FALSE, centers = NULL, 
                         centering = FALSE, seed = 123, ...)
{
  method <- match.arg(method)

  if (method=="conformal") {
    half_n <- floor(nrow(x)/2)
    x1 <- x[1:half_n,]
    x2 <- x[(half_n+1):nrow(x),]
    y1 <- y[1:half_n]
    y2 <- y[(half_n+1):nrow(x)]
    fit1 <- fit_matern32(x1, y1, lambda = lambda, l = l, method = "chol", with_kmeans = with_kmeans, centers = centers, centering = centering, seed = seed, ...)
    fit2 <- fit_matern32(x2, y2, lambda = lambda, l = l, method = "chol", with_kmeans = with_kmeans, centers = centers, centering = centering, seed = seed, ...)
    calibrated_residuals <- y2 - predict(fit1, x2)
    fit2$resid <- calibrated_residuals
    fit2$calibrated_residuals <- calibrated_residuals
    return(fit2)
  }
  #
  # train_cov = amp*cov_map(exp_quadratic, x) + eye * (noise + 1e-6)
  # chol = scipy.linalg.cholesky(train_cov, lower=True)
  # kinvy = scipy.linalg.solve_triangular(
  #   chol.T, scipy.linalg.solve_triangular(chol, y, lower=True))
  #
  # matern32::jax$scipy$linalg$cholesky()
  # matern32::jax$scipy$linalg$solve_triangular()
  
  ## regression ----
  x <- as.matrix(x)
  y <- as.vector(y)
  nlambda <- length(lambda)
  n <- dim(x)[1]
  p <- dim(x)[2]
  stopifnot(n == length(y))
  one_lambda <- (length(lambda) <= 1)
  cclust_obj <- NULL

    
  # centered response?
  if (centering)
  {
    ym <- mean(y)
    response_y <- y - ym 
  } else {
    ym <- mean(y)
    response_y <- y
  }
  
  # construct covariance
  x_scaled <- matern32::my_scale(x)
  X <- x_scaled$res
  X_clust <- NULL
  
  if (is.null(l))
    l <- sqrt(p)
  
  # compute kernel as a vector if necessary
  if (length(l) == 1)
    l <- rep(l, p)
  
  
  # 1 - compute kernel K -----
  
  # 1 - 1 - K for n > 500 -----
  if(n > 500) # can use kmeans
  {
    
    # 1 - 1 - 1 K with k-means -----
      if (with_kmeans == TRUE)
      {
        
        # adjust KRR to centers = X and this new response = y
        if (is.null(centers))
        {
          # find best k in kmeans if 'cl' is NULL
          # see https://uc-r.github.io/kmeans_clustering#optimal 
          warning("with_kmeans == TRUE but 'centers' not provided: set to 100")
          centers <- 100
          
        }
          #is.null(centers) == FALSE
          # fitted values, residuals, etc => predict on entire dataset from reduced kernel 
          
          #set.seed(seed)
          #cclust_obj <- cclust::cclust(x = as.matrix(X), 
          #                             centers = centers)
          #X_clust <- as.matrix(cclust_obj$centers)
        
         set.seed(seed)  
         cclust_obj <- stats::kmeans(x = as.matrix(X), centers = centers)
         X_clust <- as.matrix(cclust_obj$centers)
          
          response_y_clust <- sapply(1:centers, 
                                     function(i) median(response_y[which(cclust_obj$cluster == i)]))
          K <- matern32_kxx_cpp(x = X_clust, l = l)  
        
        
      } else { 
        
    # 1 - 1 - 2 K without k-means -----  
        cat("Processing... (try using option 'with_kmeans' for faster results when nrow(x) > 500)", "\n") 
        K <- matern32_kxx_cpp(x = X, l = l)   
      }
    
  } else { 
    
    # 1 - 2 - K for n <= 500 -----
      if (with_kmeans == TRUE)
      {
        
    # 1 - 2 - 1 with k-means -----      
        stop("option 'with_kmeans' not useful for n_obs <= 500")
      } else {
        
    # 1 - 2 - 2 without k-means -----            
        K <- matern32_kxx_cpp(x = X, l = l)  
      }
    
  }
  
  
  # 2 - compute coeffs -----
  
  if (with_kmeans == FALSE)
  {
    
  # 2 - 1 - without k-means -----
    
    if (method == "solve")
    {
      if (one_lambda)
      {
        K_plus <- K + lambda*diag(dim(K)[1])
        invK <- solve(K_plus)
        coef <- invK%*%response_y
        loocv <- sum(drop(coef/diag(invK))^2)
      } else { # length(lambda) > 1
        
        get_loocv <- function(lambda_i)
        {
          K_plus <- K + lambda_i*diag(dim(K)[1])
          invK <- solve(K_plus)
          coef <- invK%*%response_y
          return(list(coef = coef,
                      loocv = drop(coef/diag(invK))))
        }
        
        fit_res <- lapply(lambda, function(x) get_loocv(x))
        n_fit_res <- length(fit_res)
        
        loocv <- colSums(sapply(1:n_fit_res,  
                                function(i) fit_res[[i]]$loocv)^2)
        names(loocv) <- lambda
        
        coefs <- sapply(1:n_fit_res,  function(i) fit_res[[i]]$coef)
        colnames(coefs) <- lambda
      }
    }
    
    if (method == "svd")
    {
      Xs <- La.svd(K)
      rhs <- crossprod(Xs$u, response_y)
      d <- Xs$d
      nb_di <- length(d)
      div <- d ^ 2 + rep(lambda, rep(nb_di, nlambda))
      a <- drop(d * rhs) / div
      dim(a) <- c(nb_di, nlambda)
      coef <- crossprod(Xs$vt, a)
      colnames(coef) <- lambda
      
      response_y_hat <- K %*% coef
     
      if (centering)
      {
        fitted_values <- drop(ym +  response_y_hat) 
      } else {
        fitted_values <- drop(response_y_hat)
      }
      
      resid <- response_y - response_y_hat
      colnames(resid) <- lambda
      GCV <- colSums(resid^2)/(nrow(X) - colSums(matrix(d^2/div, 
                                                        nb_di)))^2
      
      if (length(lambda) > 1)
      {
        RSS <- colSums((y - fitted_values)^2)
      } else {
        RSS <- sum((y - fitted_values)^2)
      }
      
      TSS <- sum((y - ym)^2)
      R_Squared <- 1 - RSS/TSS
      names(R_Squared) <- lambda
      Adj_R_Squared <- 1 - (1 - R_Squared)*((n - 1)/(n - p - 1))
      
      res <- list(K = K, l = l, 
                  lambda = lambda,
                  coef = drop(coef), 
                  centering = centering,
                  scales = x_scaled$xsd,
                  ym = ym, xm = x_scaled$xm,
                  fitted_values = fitted_values, resid = resid,
                  GCV = GCV, R_Squared = R_Squared, 
                  Adj_R_Squared = Adj_R_Squared,
                  scaled_x = X,
                  with_kmeans = with_kmeans,
                  cclust_obj = cclust_obj, 
                  scaled_x_clust = X_clust, 
                  x = x, response_y = response_y, 
                  fit_method = method)
      
      class(res) <- "matern32"
      
      return(res)
    }
    
    if (method == "chol")
    {
      if (one_lambda)
      {
        K_plus <- K + lambda*diag(dim(K)[1])
        invK <- chol2inv(chol(K_plus))
        coef <- invK%*%response_y
        loocv <- sum(drop(coef/diag(invK))^2)
      } else { # length(lambda) > 1
        
        get_loocv <- function(lambda_i)
        {
          K_plus <- K + lambda_i*diag(dim(K)[1])
          invK <- chol2inv(chol(K_plus))
          coef <- invK%*%response_y
          return(list(coef = coef,
                      loocv = drop(coef/diag(invK))))
        }
        
        fit_res <- lapply(lambda, function(x) get_loocv(x))
        n_fit_res <- length(fit_res)
        
        loocv <- colSums(sapply(1:n_fit_res,  
                                function(i) fit_res[[i]]$loocv)^2)
        names(loocv) <- lambda
        
        coefs <- sapply(1:n_fit_res,  function(i) fit_res[[i]]$coef)
        colnames(coefs) <- lambda
      }
    }
    
    if (method == "eigen")
    {
      if(one_lambda)
      {
        eigenK <- base::eigen(K)
        eigen_values <- eigenK$values
        Q <- eigenK$vectors 
        inv_eigen <- solve_eigen(Eigenvectors = Q,
                                 Eigenvalues = eigen_values,
                                 y = response_y,
                                 lambda = lambda)
        
        coef <- inv_eigen$coeffs
        loocv <- sum(inv_eigen$loocv^2)
      } else { # length(lambda) > 1
        
        get_loocv <- function(lambda_i)
        {
          eigenK <- base::eigen(K)
          eigen_values <- eigenK$values
          Q <- eigenK$vectors 
          inv_eigen <- solve_eigen(Eigenvectors = Q,
                                   Eigenvalues = eigen_values,
                                   y = response_y,
                                   lambda = lambda_i)
          return(list(coef = inv_eigen$coef,
                      loocv = inv_eigen$loocv))
        }
        
        fit_res <- lapply(lambda, function(x) get_loocv(x))
        n_fit_res <- length(fit_res)
        
        loocv <- colSums(sapply(1:n_fit_res,  
                                function(i) fit_res[[i]]$loocv)^2)
        names(loocv) <- lambda
        
        coefs <- sapply(1:n_fit_res,  function(i) fit_res[[i]]$coef)
        colnames(coefs) <- lambda
        
      }
    }
    
  } else { 
    
  # 2 - 2 - with k-means -----
    if (n > 500)
    {
      # 2 - 2 - 1 For n > 500 -----
        
      if (method %in% c("chol", "solve"))
      {
        if (one_lambda)
        {
          K_plus <- K + lambda*diag(dim(K)[1])
          invK <- switch(method,
                         "solve" = solve(K_plus),
                         "chol" = chol2inv(chol(K_plus)))
          coef <- invK%*%response_y_clust
          loocv <- sum(drop(coef/diag(invK))^2)
        } else { # length(lambda) > 1
          
          get_loocv <- function(lambda_i)
          {
            K_plus <- K + lambda_i*diag(dim(K)[1])
            invK <- switch(method,
                           "solve" = solve(K_plus),
                           "chol" = chol2inv(chol(K_plus)))
            coef <- invK%*%response_y_clust
            return(list(coef = coef,
                        loocv = drop(coef/diag(invK))))
          }
          
          fit_res <- lapply(lambda, function(x) get_loocv(x))
          n_fit_res <- length(fit_res)
          
          loocv <- colSums(sapply(1:n_fit_res,  
                                  function(i) fit_res[[i]]$loocv)^2)
          names(loocv) <- lambda
          
          coefs <- sapply(1:n_fit_res,  function(i) fit_res[[i]]$coef)
          colnames(coefs) <- lambda
        }
      }
      
      if (method == "svd")
      {
        Xs <- La.svd(K) # K is based on clustered X 
        rhs <- crossprod(Xs$u, response_y_clust)
        d <- Xs$d
        nb_di <- length(d)
        div <- d ^ 2 + rep(lambda, rep(nb_di, nlambda))
        a <- drop(d * rhs) / div
        dim(a) <- c(nb_di, nlambda)
        coef <- crossprod(Xs$vt, a)
        colnames(coef) <- lambda
        scales <- x_scaled$xsd
        xm <- x_scaled$xm
        
        K_star <- matern32_kxstar_cpp(newx = X, # X is already scaled
                                      x = X_clust, 
                                      l = l)
        
        response_y_hat <- K_star%*%coef 
        
        if (centering)
        {
          fitted_values <- drop(ym +  response_y_hat) 
        } else {
          fitted_values <- drop(response_y_hat)
        }
        
        resid <- response_y - response_y_hat
        colnames(resid) <- lambda
        GCV <- colSums(resid^2)/(nrow(X) - colSums(matrix(d^2/div, 
                                                          nb_di)))^2
        
        if (length(lambda) > 1)
        {
          RSS <- colSums((y - fitted_values)^2)
        } else {
          RSS <- sum((y - fitted_values)^2)
        }
        
        TSS <- sum((y - ym)^2)
        R_Squared <- 1 - RSS/TSS
        Adj_R_Squared <- 1 - (1 - R_Squared)*((n - 1)/(n - p - 1))
        names(R_Squared) <- lambda
        
      }
      
    } else {
      
      # 2 - 2 - 2 For n <= 500 -----
      stop("option 'with_kmeans' not implemented for n_obs <= 500")
      
    }
    
  }
  
  
  # 3 - returns -----
  
  
  # 3 - 1 svd -----
  if (method == "svd")
  {
    res <- list(K = K, l = l, 
                lambda = lambda,
                coef = drop(coef),
                centering = centering,
                scales = scales,
                ym = ym, xm = xm,
                fitted_values = fitted_values, resid = resid,
                GCV = GCV, R_Squared = R_Squared, 
                Adj_R_Squared = Adj_R_Squared,
                scaled_x = X, 
                x = x, 
                with_kmeans = with_kmeans,
                cclust_obj = cclust_obj, 
                scaled_x_clust = X_clust, 
                response_y = response_y, 
                fit_method = method)
    
    class(res) <- "matern32"
    
    return(res)
  }
  
  # 3 - 2 solve, chol, eigen -----
  if (method %in% c("solve", "chol", "eigen"))
  {
    if (length(lambda) == 1)
    {
      if (!with_kmeans)
      {
        response_y_hat <- K %*% coef
      } else {
        K_star <- matern32_kxstar_cpp(newx = X, # X is already scaled
                                      x = X_clust, 
                                      l = l)
        
        response_y_hat <- K_star%*%coef 
      }
      
      if (centering)
      {
        fitted_values <- drop(ym +  response_y_hat) 
      } else {
        fitted_values <- drop(response_y_hat)
      }
      
      resid <- response_y - response_y_hat
      
      RSS <- sum((y - fitted_values)^2)
      TSS <- sum((y - ym)^2)
      R_Squared <- 1 - RSS/TSS
      Adj_R_Squared <- 1 - (1 - R_Squared)*((n - 1)/(n - p - 1))
      
      res <- list(K = K, l = l, 
                  lambda = lambda,
                  coef = drop(coef), 
                  centering = centering,
                  scales = x_scaled$xsd,
                  ym = ym, xm = x_scaled$xm,
                  fitted_values = fitted_values, resid = drop(resid),
                  loocv = loocv, R_Squared = R_Squared, 
                  Adj_R_Squared = Adj_R_Squared, 
                  scaled_x = X, 
                  x = x, 
                  with_kmeans = with_kmeans,
                  cclust_obj = cclust_obj, 
                  scaled_x_clust = X_clust, 
                  response_y = response_y, 
                  fit_method = method)
      
      class(res) <- "matern32"
      
      return(res)  
    } else { 
      
      if (!with_kmeans)
      {
        response_y_hat <- K %*% coefs # coef with s
      } else {
        K_star <- matern32_kxstar_cpp(newx = X, # X is already scaled
                                      x = X_clust, 
                                      l = l)
        
        response_y_hat <- K_star%*%coefs # coef with s
      }
      
      if (centering)
      {
        fitted_values <- drop(ym +  response_y_hat) 
      } else {
        fitted_values <- drop(response_y_hat)
      }
      
      resid <- response_y - response_y_hat
      
      RSS <- colSums((y - fitted_values)^2)
      TSS <- sum((y - ym)^2)
      R_Squared <- 1 - RSS/TSS
      names(R_Squared) <- lambda
      Adj_R_Squared <- 1 - (1 - R_Squared)*((n - 1)/(n - p - 1))
      
      res <- list(K = K, l = l, 
                  lambda = lambda,
                  coef = drop(coefs), 
                  centering = centering,
                  scales = x_scaled$xsd,
                  ym = ym, xm = x_scaled$xm,
                  fitted_values = fitted_values, resid = resid,
                  loocv = loocv, R_Squared = R_Squared, 
                  Adj_R_Squared = Adj_R_Squared, 
                  scaled_x = X, 
                  x = x, 
                  with_kmeans = with_kmeans,
                  cclust_obj = cclust_obj, 
                  scaled_x_clust = X_clust, 
                  response_y = response_y, 
                  fit_method = method)
      
      class(res) <- "matern32"
      
      return(res) 
    }
  }
}
#fit_matern32 <- memoise::memoize(fit_matern32)