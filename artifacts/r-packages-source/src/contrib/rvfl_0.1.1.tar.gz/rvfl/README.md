# rvfl

[![Documentation](https://img.shields.io/badge/documentation-is_here-green)](https://techtonique.github.io/rvfl/index.html)

Random Vector Functional Link networks 
