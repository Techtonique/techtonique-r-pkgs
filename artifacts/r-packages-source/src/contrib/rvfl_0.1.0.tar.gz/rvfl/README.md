# rvfl

Random Vector Functional Link networks 
