# 2025-10-02

- Fix `parfor`

# 2025-08-13

- `sims_to_forecast_object`
- `mspl`(Mean Scaled Pinball Loss for Quantile Forecasts)

# 2025-07-21

- update `plot_prediction_interval` with true future value
- add `get_next_date` (next value of a time series)
