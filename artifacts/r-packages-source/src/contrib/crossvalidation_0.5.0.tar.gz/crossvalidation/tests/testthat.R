library(testthat)
library(crossvalidation)

test_check("crossvalidation")
