# learningmachine (R version)

Machine Learning with Explanations and Uncertainty Quantification

[![Documentation](https://img.shields.io/badge/documentation-is_here-green)](https://techtonique.github.io/learningmachine/)
[![HitCount](https://hits.dwyl.com/Techtonique/learningmachine.svg?style=flat-square)](http://hits.dwyl.com/Techtonique/learningmachine) 
![Downloads](https://r-packages.techtonique.net/badges/downloads/last-month/ahead.svg)
![Total Downloads](https://r-packages.techtonique.net/badges/downloads/grand-total/ahead.svg?color=brightgreen)


**Install from Techtonique repo**

```R
install.packages("learningmachine", repos = c("https://r-packages.techtonique.net", "https://cloud.r-project.org"))
```

**Examples**

Read the [vignettes](./vignettes)
