quadratic <-
function(u)
{
  return(1 - (u)^2)
}
