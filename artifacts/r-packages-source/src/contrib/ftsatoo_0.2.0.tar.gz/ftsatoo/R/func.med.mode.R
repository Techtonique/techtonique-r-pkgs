func.med.mode <- function(functions)
{
  depth.mode(functions)$median
}

