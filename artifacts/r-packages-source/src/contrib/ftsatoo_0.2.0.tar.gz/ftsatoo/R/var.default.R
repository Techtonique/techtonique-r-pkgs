var.default <- function (...) 
{
	stats::var(...)
}
