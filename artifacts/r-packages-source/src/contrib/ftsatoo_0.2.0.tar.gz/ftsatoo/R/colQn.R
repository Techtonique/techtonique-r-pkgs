colQn <- function (Z)
{
    return(apply(Z, 2, Qn))
}
