var <- function(...) 
UseMethod("var")
