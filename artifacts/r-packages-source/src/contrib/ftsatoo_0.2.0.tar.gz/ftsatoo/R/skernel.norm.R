skernel.norm <- function(x)
{
 sum(dnorm(x))
}
