tsse <-
function(x1, x2){
  sqrt(sum((x1 - x2) ^ 2))
}
