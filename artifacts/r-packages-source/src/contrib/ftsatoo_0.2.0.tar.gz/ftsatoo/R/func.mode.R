func.mode <- function(functions, h = 0.20)
{
  depth.mode(functions)
}

