# 2025-07-21

- update `plot_prediction_interval` with true future value
- add `get_next_date` (next value of a time series)